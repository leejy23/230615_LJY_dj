using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMove : MonoBehaviour{
    int step = 0;



    void Update()
    {


    }
   
}
